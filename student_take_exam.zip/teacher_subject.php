<?php
include 'connection.php';

if (!isset($_SESSION["user_id"]) || $_SESSION["User_role"] !== "Teacher") {
    echo '<script>alert("Access denied! Redirecting..."); window.location.href = "login.php";</script>';
    exit();
}

$teacher_id = $_SESSION['user_id'];

function generateSubjectCode()
{
    return substr(str_shuffle("ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"), 0, 6);
}

if (isset($_POST['create'])) {
    $subject_name = $_POST['subject_name'];
    $subject_code = generateSubjectCode();
    
    $sql = "INSERT INTO subjects (teacher_id, subject_name, subject_code) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iss", $teacher_id, $subject_name, $subject_code);
    if ($stmt->execute()) {
        echo "<script>alert('Subject Created Successfully!'); window.location.href='teacher_subject.php';</script>";
    } else {
        echo "<script>alert('Error creating subject. Try again!');</script>";
    }
}

if (isset($_POST['update'])) {
    $subject_id = $_POST['sub_id'];
    $subject_name = trim($_POST['subject_name']);
    
    $sql = "UPDATE subjects SET subject_name = ? WHERE sub_id = ? AND teacher_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sii", $subject_name, $subject_id, $teacher_id);
    if ($stmt->execute()) {
        echo "<script>alert('Subject Updated Successfully!'); window.location.href='teacher_subject.php';</script>";
    }
}

if (isset($_POST['delete'])) {
    $subject_id = $_POST['sub_id'];
    
    $sql = "DELETE FROM subjects WHERE sub_id = ? AND teacher_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $subject_id, $teacher_id);
    if ($stmt->execute()) {
        echo "<script>alert('Subject Deleted Successfully!'); window.location.href='teacher_subject.php';</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teacher Dashboard</title>
    <link rel="stylesheet" href="assets/bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
            color: #333;
        }
        .sidebar {
            background-color: #2E7D32;
            color: white;
            height: 100vh;
            padding-top: 20px;
        }
        .sidebar a {
            color: white;
            text-decoration: none;
            display: block;
            padding: 10px;
        }
        .sidebar a:hover {
            background-color: rgb(25, 135, 84);
        }
        .main-content {
            padding: 20px;
        }
        .card {
            border-left: 5px solid #2E7D32;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <nav class="col-md-3 col-lg-2 sidebar d-md-block bg-success text-white p-3">
                <h4 class="text-center">Teacher Panel</h4>
                <a href="teacher_dashboard.php" class="text-white">Dashboard</a>
                <a href="teacher_subject.php" class="text-white">Subject Class</a>
                <div class="dropdown">
                    <a class="dropdown-toggle text-white" href="#" role="button" id="examDropdown"
                        data-bs-toggle="dropdown" aria-expanded="false">
                        Exams
                    </a>
                    <ul class="dropdown-menu bg-success" aria-labelledby="examDropdown">
                        <li><a class="dropdown-item" href="teacher_exams.php">Create Exam</a></li>
                        <li><a class="dropdown-item" href="teacher_viewexams.php">View Exams</a></li>
                        <li><a class="dropdown-item" href="teacher_questions.php">Exam Questions</a></li>
                    </ul>
                </div>
                <a href="#" class="text-white">Upload Reviewer</a>
                <a href="logout.php" class="text-white">Logout</a>
            </nav>
            
            <main class="col-md-9 col-lg-10 p-4">
                <h2 class="text-success">Manage Subjects</h2>
                <form method="POST">
                    <input type="text" name="subject_name" class="form-control" placeholder="Enter Subject Name" required>
                    <button type="submit" name="create" class="btn btn-success mt-2">Create Subject</button>
                </form>
                <hr>
                <h4>Your Subjects</h4>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Subject Name</th>
                            <th>Subject Code</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $sql = "SELECT * FROM subjects WHERE teacher_id = ?";
                        $stmt = $conn->prepare($sql);
                        $stmt->bind_param("i", $teacher_id);
                        $stmt->execute();
                        $result = $stmt->get_result();
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr>
                                <td>{$row['subject_name']}</td>
                                <td>{$row['subject_code']}</td>
                                <td>
                                    <form method='POST' style='display:inline;'>
                                        <input type='hidden' name='sub_id' value='{$row['sub_id']}'>
                                        <input type='text' name='subject_name' value='{$row['subject_name']}' required>
                                        <button type='submit' name='update' class='btn btn-warning btn-sm'>Update</button>
                                    </form>
                                    <form method='POST' style='display:inline;'>
                                        <input type='hidden' name='sub_id' value='{$row['sub_id']}'>
                                        <button type='submit' name='delete' class='btn btn-danger btn-sm' onclick='return confirm('\Are you sure?\')'>Delete</button>
                                    </form>
                                </td>
                            </tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </main>
        </div>
    </div>
    <script src="assets/bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
