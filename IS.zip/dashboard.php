<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <title>Dashboard</title>
</head>
<body>

<header class="display-4 text-center">Welcome Admin!</header>

<div class="d-flex">
    <!-- Sidebar -->
    <div class="sidebar p-4 bg-light">
        <img src="Green_Vintage_Agriculture_and_Farming_Logo-removebg-preview.png" alt="">
        <p>Barangay Abayon</p>
        <div class="nav-items">
            <h3>Dashboard</h3>
            <a href="#">Manage Residents</a><br><br>
            <a href="#">Manage Complaints</a><br><br>
            <a href="#">Manage Officials</a><br><br><br><br>
            <button class="btn btn-danger">Logout</button>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content p-4">
        <h2>Barangay Abayon Information System</h2>
<br><br><br>
        <!-- Stat Boxes Section -->
        <div class="row text-center">
            <!-- Stat Box 1 -->
            <div class="col-md-4">
                <div class="card bg-primary text-white mb-3">
                    <div class="card-body">
                        <h4 class="card-title">Total Household</h4>
                        <p class="card-text display-4">1,230</p>
                    </div>
                </div>
            </div>

            <!-- Stat Box 2 -->
            <div class="col-md-4">
                <div class="card bg-success text-white mb-3">
                    <div class="card-body">
                        <h4 class="card-title">Total Population</h4>
                        <p class="card-text display-4">45</p>
                    </div>
                </div>
            </div>

            <!-- Stat Box 3 -->
            <div class="col-md-4">
                <div class="card bg-warning text-white mb-3">
                    <div class="card-body">
                        <h4 class="card-title">Male</h4>
                        <p class="card-text display-4">12</p>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card bg-warning text-white mb-3">
                    <div class="card-body">
                        <h4 class="card-title">Female</h4>
                        <p class="card-text display-4">12</p>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card bg-warning text-white mb-3">
                    <div class="card-body">
                        <h4 class="card-title">Children</h4>
                        <p class="card-text display-4">12</p>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card bg-warning text-white mb-3">
                    <div class="card-body">
                        <h4 class="card-title">Senior</h4>
                        <p class="card-text display-4">12</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="bootstrap-5.3.3-dist/js/bootstrap.min.js"></script>
</body>
</html>

<style>
    .d-flex {
        display: flex;
        height: 100vh; /* Full height */
    }

    .sidebar {
        width: 250px;
        text-align: center;
    }

    .main-content {
        flex-grow: 1; /* Takes the remaining space */
    }

    img {
        width: 100%;
    }

    .card-text {
        font-size: 2.5rem;
        font-weight: bold;
    }
</style>
