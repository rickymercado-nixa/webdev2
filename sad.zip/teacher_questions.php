<?php
include 'connection.php';

if (!isset($_SESSION['User_role']) || $_SESSION['User_role'] !== 'Teacher') {
    echo "<script>alert('Access Denied!'); window.location.href='dashboard.php';</script>";
    exit();
}

$teacher_id = $_SESSION['user_id'];
$exam_id = isset($_GET['exam_id']) ? intval($_GET['exam_id']) : 0;

// Validate exam ownership
$sql = "SELECT * FROM exams WHERE exam_id = ? AND teacher_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $exam_id, $teacher_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    die("<script>alert('Invalid Exam!'); window.location.href='teacher_viewexams.php';</script>");
}

$exam = $result->fetch_assoc();

// Fetch existing questions
$questionQuery = "SELECT * FROM questions WHERE exam_id = ?";
$stmt = $conn->prepare($questionQuery);
$stmt->bind_param("i", $exam_id);
$stmt->execute();
$questions = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Manage Questions</title>
    <link rel="stylesheet" href="assets/bootstrap-5.3.3-dist/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-4">
    <h2>Manage Questions for: <?= htmlspecialchars($exam['exam_name']) ?></h2>
    <a href="teacher_viewexams.php" class="btn btn-secondary mb-3">Back to Exams</a>
    <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#addQuestionModal">Add Question</button>

    <table class="table mt-3">
        <thead>
            <tr>
                <th>Question</th>
                <th>Type</th>
                <th>Marks</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        <?php while ($row = $questions->fetch_assoc()) : ?>
            <tr>
                <td><?= htmlspecialchars($row['question_text']) ?></td>
                <td><?= htmlspecialchars($row['question_type']) ?></td>
                <td><?= $row['marks'] ?></td>
                <td>
                    <a href="edit_question.php?question_id=<?= $row['question_id'] ?>" class="btn btn-primary btn-sm">Edit</a>
                    <form method="POST" action="delete_question.php" class="d-inline">
                        <input type="hidden" name="question_id" value="<?= $row['question_id'] ?>">
                        <button type="submit" name="delete" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?')">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endwhile; ?>
        </tbody>
    </table>
</div>

<!-- Add Question Modal -->
<div class="modal fade" id="addQuestionModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add Question</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" action="teacher_addquestions.php">
                <div class="modal-body">
                    <input type="hidden" name="exam_id" value="<?= $exam_id ?>">
                    <label class="form-label">Question Type</label>
                    <select name="question_type" class="form-control" required>
                        <option value="Multiple Choice">Multiple Choice</option>
                        <option value="True/False">True/False</option>
                        <option value="Fill in the Blanks">Fill in the Blanks</option>
                    </select>
                    <label class="form-label">Question</label>
                    <textarea name="question_text" class="form-control" required></textarea>
                    <label class="form-label">Marks</label>
                    <input type="number" name="marks" class="form-control" required>
                </div>
                <div class="modal-footer">
                    <button type="submit" name="add" class="btn btn-success">Add</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="assets/bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
