<?php
include 'connection.php';

if (!isset($_SESSION["user_id"]) || $_SESSION["User_role"] !== "Teacher") {
    echo '<script>alert("Access denied! Redirecting..."); window.location.href = "login.php";</script>';
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add'])) {
    $exam_id = $_POST['exam_id'];
    $question_text = trim($_POST['question_text']);
    $question_type = $_POST['question_type'];
    $marks = intval($_POST['marks']);

    $sql = "INSERT INTO questions (exam_id, question_text, question_type, marks) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("issi", $exam_id, $question_text, $question_type, $marks);

    if ($stmt->execute()) {
        echo "<script>alert('Question added successfully!'); window.location.href='teacher_questions.php?exam_id=$exam_id';</script>";
    } else {
        echo "<script>alert('Error adding question!'); history.back();</script>";
    }
}
?>
