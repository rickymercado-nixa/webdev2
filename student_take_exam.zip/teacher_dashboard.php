<?php
    require 'connection.php';

    if (!isset($_SESSION["user_id"]) || $_SESSION["User_role"] !== "Teacher") {
        echo '<script>alert("Access denied! Redirecting..."); window.location.href = "login.php";</script>';
        exit();
    }

    $user_id = $_SESSION["user_id"];
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teacher Dashboard</title>
    <link rel="stylesheet" href="assets/bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fontawesome-free-6.7.2-web/css/all.css">
    <style>
    body {
        background-color: #f8f9fa;
        color: #333;
    }

    .sidebar {
        color: white;
        height: 100vh;
        padding-top: 20px;
    }

    .sidebar a {
        color: white;
        text-decoration: none;
        display: block;
        padding: 10px;
    }

    .sidebar a:hover {
        background-color: rgb(25, 135, 84);
    }

    .main-content {
        padding: 20px;
    }

    .card {
        border-left: 5px solid #2E7D32;
    }
    </style>
</head>

<body>
    <div class="container-fluid">
        <div class="row">
            <nav class="col-md-3 col-lg-2 sidebar d-md-block bg-success">
                <h4 class="text-center">Teacher Panel</h4>
                <a href="teacher_dashboard.php">Dashboard</a>
                <a href="teacher_subject.php">Subjects</a>

                <div class="dropdown">
                    <a class="dropdown-toggle text-white" href="#" role="button" id="examDropdown"
                        data-bs-toggle="dropdown" aria-expanded="false">
                        Exams
                    </a>
                    <ul class="dropdown-menu bg-success" aria-labelledby="examDropdown">
                        <li><a class="dropdown-item" href="teacher_exams.php">Create Exam</a></li>
                        <li><a class="dropdown-item" href="teacher_viewexams.php">View Exams</a></li>
                        <li><a class="dropdown-item" href="teacher_questions.php">Exam Questions</a></li>
                    </ul>
                </div>

                <a href="#">Upload Reviewer</a>
                <a href="logout.php">Logout</a>
            </nav>


            <main class="col-md-9 col-lg-10 main-content">
                <h2 class="mb-4">Dashboard Overview</h2>

                <div class="row">
                    <div class="col-md-4">
                        <div class="card p-3">
                            <h5>Subjects</h5>
                            <p>Total: 5</p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card p-3">
                            <h5>Exams</h5>
                            <p>Total: 10</p>
                        </div>
                    </div>
                    <?php
                        echo $user_id;
                    ?>
                    <div class="col-md-4">
                        <div class="card p-3">
                            <h5>Reviewers</h5>
                            <p>Total: 7</p>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>
    <script src="assets/bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>