<?php
include 'connection.php';

if (!isset($_SESSION['User_role']) || $_SESSION['User_role'] !== 'Teacher') {
    echo "<script>alert('Access Denied!'); window.location.href='dashboard.php';</script>";
    exit();
}

$teacher_id = $_SESSION['user_id'];

if (isset($_POST['update'])) {
    $exam_id = $_POST['exam_id'];
    $exam_name = trim($_POST['exam_name']);
    $total_marks = $_POST['total_marks'];
    $duration = $_POST['duration'];
    $start_time = $_POST['start_time'];
    $end_time = $_POST['end_time'];
    $status = $_POST['status'];

    $sql = "UPDATE exams SET exam_name = ?, total_marks = ?, duration = ?, start_time = ?, end_time = ?, status = ? WHERE exam_id = ? AND teacher_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("siisssii", $exam_name, $total_marks, $duration, $start_time, $end_time, $status, $exam_id, $teacher_id);
    if ($stmt->execute()) {
        echo "<script>alert('Exam Updated Successfully!'); window.location.href='teacher_viewexams.php';</script>";
    }
}

if (isset($_POST['delete'])) {
    $exam_id = $_POST['exam_id'];
    $sql = "DELETE FROM exams WHERE exam_id = ? AND teacher_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $exam_id, $teacher_id);
    if ($stmt->execute()) {
        echo "<script>alert('Exam Deleted Successfully!'); window.location.href='teacher_viewexams.php';</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Exams</title>
    <link rel="stylesheet" href="assets/bootstrap-5.3.3-dist/css/bootstrap.min.css">
</head>
<style>
        body {
            background-color: #f8f9fa;
            color: #333;
        }
        .sidebar {
            background-color: #2E7D32;
            color: white;
            height: 100vh;
            padding-top: 20px;
        }
        .sidebar a {
            color: white;
            text-decoration: none;
            display: block;
            padding: 10px;
        }
        .sidebar a:hover {
            background-color: rgb(25, 135, 84);
        }
        .main-content {
            padding: 20px;
        }
        .card {
            border-left: 5px solid #2E7D32;
        }
</style>
<div class="container-fluid">
<div class="row">
        <nav class="col-md-3 col-lg-2 sidebar d-md-block bg-success text-white p-3">
            <h4 class="text-center">Teacher Panel</h4>
            <a href="teacher_dashboard.php" class="text-white">Dashboard</a>
            <a href="teacher_subject.php" class="text-white">Subject Class</a>
            <div class="dropdown">
                <button class="btn text-white dropdown-toggle w-100 text-start" type="button" id="examDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                    Exams
                </button>
                <ul class="dropdown-menu bg-success" aria-labelledby="examDropdown">
                    <li><a class="dropdown-item" href="teacher_exams.php">Create Exam</a></li>
                    <li><a class="dropdown-item" href="teacher_viewexams.php">View Exams</a></li>
                    <li><a class="dropdown-item" href="teacher_questions.php">Exam Questions</a></li>
                </ul>
            </div>
            <a href="#" class="text-white">Upload Reviewer</a>
            <a href="logout.php" class="text-white">Logout</a>
        </nav>

        <main class="col-md-9 col-lg-10 main-content">
    <h2 class="text-success">Manage Exams</h2>
    <table class="table table-bordered">
        <thead>
        <tr>
            <th>Exam Name</th>
            <th>Subject</th>
            <th>Total Marks</th>
            <th>Duration</th>
            <th>Start Time</th>
            <th>End Time</th>
            <th>Status</th>
            <th>Actions</th>
        </tr>
        </thead>
        <tbody>
        <?php
        $sql = "SELECT exams.*, subjects.subject_name FROM exams JOIN subjects ON exams.sub_id = subjects.sub_id WHERE exams.teacher_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $teacher_id);
        $stmt->execute();
        $result = $stmt->get_result();
        while ($row = $result->fetch_assoc()) {
            echo "<tr>
                <td>{$row['exam_name']}</td>
                <td>{$row['subject_name']}</td>
                <td>{$row['total_marks']}</td>
                <td>{$row['duration']}</td>
                <td>{$row['start_time']}</td>
                <td>{$row['end_time']}</td>
                <td>{$row['status']}</td>
                <td>
                    <button class='btn btn-primary btn-sm' data-bs-toggle='modal' data-bs-target='#editExamModal{$row['exam_id']}'>Edit</button>
                    <form method='POST' class='d-inline'>
                        <input type='hidden' name='exam_id' value='{$row['exam_id']}'>
                        <button type='submit' name='delete' class='btn btn-danger btn-sm' onclick='return confirm('\Are you sure?\')'>Delete</button>
                    </form>
                </td>
                <td>
    <a href='teacher_questions.php?exam_id={$row['exam_id']}' class='btn btn-warning btn-sm'>Manage Questions</a>
    <button class='btn btn-primary btn-sm' data-bs-toggle='modal' data-bs-target='#editExamModal{$row['exam_id']}'>Edit</button>
    <form method='POST' class='d-inline'>
        <input type='hidden' name='exam_id' value='{$row['exam_id']}'>
        <button type='submit' name='delete' class='btn btn-danger btn-sm' onclick='return confirm('\Are you sure?\')'>Delete</button>
    </form>
</td>

            </tr>";
            
            echo "<div class='modal fade' id='editExamModal{$row['exam_id']}' tabindex='-1' aria-hidden='true'>
                <div class='modal-dialog'>
                    <div class='modal-content'>
                        <div class='modal-header'>
                            <h5 class='modal-title'>Edit Exam</h5>
                            <button type='button' class='btn-close' data-bs-dismiss='modal' aria-label='Close'></button>
                        </div>
                        <form method='POST'>
                            <div class='modal-body'>
                                <input type='hidden' name='exam_id' value='{$row['exam_id']}'>
                                <label class='form-label'>Exam Name</label>
                                <input type='text' name='exam_name' class='form-control' value='{$row['exam_name']}' required>
                                <label class='form-label'>Total Marks</label>
                                <input type='number' name='total_marks' class='form-control' value='{$row['total_marks']}' required>
                                <label class='form-label'>Duration (Minutes)</label>
                                <input type='number' name='duration' class='form-control' value='{$row['duration']}' required>
                                <label class='form-label'>Start Time</label>
                                <input type='datetime-local' name='start_time' class='form-control' value='{$row['start_time']}' required>
                                <label class='form-label'>End Time</label>
                                <input type='datetime-local' name='end_time' class='form-control' value='{$row['end_time']}' required>
                                <label class='form-label'>Status</label>
                                <select name='status' class='form-control' required>
                                    <option value='Upcoming' " . ($row['status'] == 'Upcoming' ? 'selected' : '') . ">Upcoming</option>
                                    <option value='Ongoing' " . ($row['status'] == 'Ongoing' ? 'selected' : '') . ">Ongoing</option>
                                    <option value='Completed' " . ($row['status'] == 'Completed' ? 'selected' : '') . ">Completed</option>
                                </select>
                            </div>
                            <div class='modal-footer'>
                                <button type='submit' name='update' class='btn btn-success'>Update</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>";
        }
        ?>
        </tbody>
    </table>
    </main>
    </div>
</div>
</div>
<script src="assets/bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
