<?php
require 'connection.php';

if (!isset($_SESSION["user_id"]) || $_SESSION["User_role"] !== "Teacher") {
    echo '<script>alert("Access denied! Redirecting..."); window.location.href = "login.php";</script>';
    exit();
}

$exam_id = $_GET['exam_id']; 

$cheating_query = "SELECT * FROM cheating_logs WHERE exam_id = '$exam_id'";
$cheating_result = mysqli_query($conn, $cheating_query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cheating Reports</title>
    <link rel="stylesheet" href="assets/bootstrap-5.3.3-dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-4">
        <h1>Cheating Reports</h1>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Student ID</th>
                    <th>Event</th>
                    <th>Time</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($log = mysqli_fetch_assoc($cheating_result)) { ?>
                    <tr>
                        <td><?php echo $log['student_id']; ?></td>
                        <td><?php echo $log['event_type']; ?></td>
                        <td><?php echo $log['timestamp']; ?></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</body>
</html>
