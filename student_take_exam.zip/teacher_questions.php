<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include 'connection.php';

if (!isset($_SESSION["user_id"]) || $_SESSION["User_role"] !== "Teacher") {
    echo '<script>alert("Access denied! Redirecting..."); window.location.href = "login.php";</script>';
    exit();
}

if (!isset($_GET['exam_id'])) {
    echo "<script>alert('Exam ID is missing!'); window.location.href='teacher_dashboard.php';</script>";
    exit();
}

$exam_id = (int)$_GET['exam_id'];
$teacher_id = $_SESSION['user_id'];

if (isset($_POST['add_question'])) {
    $exam_id = $_POST['exam_id'];
    $question_text = trim($_POST['question_text']);
    $question_type = $_POST['question_type'];
    $marks = $_POST['marks'];

    $sql = "INSERT INTO questions (exam_id, question_text, question_type, marks) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("issi", $exam_id, $question_text, $question_type, $marks);
    $stmt->execute();
    $question_id = $stmt->insert_id;

    if ($question_type === "Multiple Choice") {
        $correct_answer = (int)$_POST['correct_answer'];
        for ($i = 1; $i <= 4; $i++) {
        $choice_text = trim($_POST["choice_$i"]);
        $is_correct = ($correct_answer === $i) ? 1 : 0;
        $sql = "INSERT INTO choices (question_id, choice_text, is_correct) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("isi", $question_id, $choice_text, $is_correct);
        $stmt->execute();
    }
    } elseif ($question_type === "True/False") {
        $choices = [
            ["True", ($_POST['correct_answer'] === "True") ? 1 : 0],
            ["False", ($_POST['correct_answer'] === "False") ? 1 : 0]
        ];
        foreach ($choices as $choice) {
            $choice_text = $choice[0];
            $is_correct = $choice[1];
            $sql = "INSERT INTO choices (question_id, choice_text, is_correct) VALUES (?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("isi", $question_id, $choice_text, $is_correct);
            $stmt->execute();
        }
    } elseif ($question_type === "Fill in the Blanks") {
        $correct_answer = trim($_POST['fill_answer']);
        $sql = "INSERT INTO choices (question_id, choice_text, is_correct) VALUES (?, ?, 1)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("is", $question_id, $correct_answer);
        $stmt->execute();
    }

    echo "<script>alert('Question Added Successfully!'); window.location.href='teacher_questions.php?exam_id=$exam_id';</script>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Questions</title>
    <link rel="stylesheet" href="assets/bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <script>
    function showQuestionFields() {
        let type = document.getElementById('question_type').value;

        document.getElementById('multiple_choice_fields').style.display = (type === 'Multiple Choice') ? 'block' :
            'none';
        document.getElementById('true_false_fields').style.display = (type === 'True/False') ? 'block' : 'none';
        document.getElementById('fill_blanks_fields').style.display = (type === 'Fill in the Blanks') ? 'block' :
        'none';

        document.querySelectorAll('#multiple_choice_fields input').forEach(el => {
            el.required = (type === 'Multiple Choice');
        });

        document.querySelectorAll('#true_false_fields select').forEach(el => {
            el.required = (type === 'True/False');
        });

        document.querySelectorAll('#fill_blanks_fields input').forEach(el => {
            el.required = (type === 'Fill in the Blanks');
        });

        if (type !== 'Multiple Choice') {
            document.querySelectorAll('#multiple_choice_fields input').forEach(el => el.removeAttribute('required'));
        }
        if (type !== 'True/False') {
            document.querySelectorAll('#true_false_fields select').forEach(el => el.removeAttribute('required'));
        }
        if (type !== 'Fill in the Blanks') {
            document.querySelectorAll('#fill_blanks_fields input').forEach(el => el.removeAttribute('required'));
        }
    }

    document.addEventListener("DOMContentLoaded", function() {
        showQuestionFields();
        document.getElementById('question_type').addEventListener('change', showQuestionFields);
    });
    </script>
    <style>
        body {
            background-color: #f8f9fa;
            color: #333;
        }
        .sidebar {
            background-color: #2E7D32;
            color: white;
            height: 100vh;
            padding-top: 20px;
        }
        .sidebar a {
            color: white;
            text-decoration: none;
            display: block;
            padding: 10px;
        }
        .sidebar a:hover {
            background-color: rgb(25, 135, 84);
        }
        .main-content {
            padding: 20px;
        }
        .card {
            border-left: 5px solid #2E7D32;
            padding: 20px;
        }
        .form-label {
            font-weight: 600;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
    <div class="row">
        <nav class="col-md-3 col-lg-2 sidebar d-md-block bg-success text-white p-3">
            <h4 class="text-center">Teacher Panel</h4>
            <a href="teacher_dashboard.php" class="text-white">Dashboard</a>
            <a href="teacher_subject.php" class="text-white">Subject Class</a>
            <div class="dropdown">
                <button class="btn text-white dropdown-toggle w-100 text-start" type="button" id="examDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                    Exams
                </button>
                <ul class="dropdown-menu bg-success" aria-labelledby="examDropdown">
                    <li><a class="dropdown-item" href="teacher_exams.php">Create Exam</a></li>
                    <li><a class="dropdown-item" href="teacher_viewexams.php">View Exams</a></li>
                    <li><a class="dropdown-item" href="teacher_questions.php">Exam Questions</a></li>
                </ul>
            </div>
            <a href="#" class="text-white">Upload Reviewer</a>
            <a href="logout.php" class="text-white">Logout</a>
        </nav>

        <main class="col-md-9 col-lg-10 main-content">
        <h2 class="text-success">Manage Questions</h2>
        <button class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#addQuestionModal">Add
            Question</button>

        <div class="modal fade" id="addQuestionModal" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Add Question</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <form method="POST">
                        <div class="modal-body">
                            <label class="form-label">Exam</label>
                            <select name="exam_id" class="form-control" required>
                                <option value="">Select Exam</option>
                                <?php
                            $sql = "SELECT * FROM exams WHERE teacher_id = ?";
                            $stmt = $conn->prepare($sql);
                            $stmt->bind_param("i", $teacher_id);
                            $stmt->execute();
                            $result = $stmt->get_result();
                            while ($exam = $result->fetch_assoc()) {
                                $selected = ($exam['exam_id'] == $exam_id) ? 'selected' : '';
                                echo "<option value='{$exam['exam_id']}' $selected>{$exam['exam_name']}</option>";
                            }
                            ?>
                            </select>

                            <label class="form-label">Question Type</label>
                            <select name="question_type" id="question_type" class="form-control"
                                onchange="showQuestionFields()" required>
                                <option value="Multiple Choice">Multiple Choice</option>
                                <option value="True/False">True/False</option>
                                <option value="Short Answer">Short Answer</option>
                                <option value="Fill in the Blanks">Fill in the Blanks</option>
                            </select>

                            <label class="form-label">Question</label>
                            <input type="text" name="question_text" class="form-control" required>

                            <div id="multiple_choice_fields" style="display:none;">
                                <label class="form-label">Choices</label>
                                <input type="text" name="choice_1" class="form-control" placeholder="Choice A" required>
                                <input type="text" name="choice_2" class="form-control" placeholder="Choice B" required>
                                <input type="text" name="choice_3" class="form-control" placeholder="Choice C" required>
                                <input type="text" name="choice_4" class="form-control" placeholder="Choice D" required>

                                <label class="form-label">Correct Answer</label>
                                <select name="correct_answer" class="form-control" required>
                                    <option value="1">Choice A</option>
                                    <option value="2">Choice B</option>
                                    <option value="3">Choice C</option>
                                    <option value="4">Choice D</option>
                                </select>
                            </div>


                            <div id="true_false_fields" style="display:none;">
                                <label class="form-label">Correct Answer</label>
                                <select name="correct_answer" class="form-control" required>
                                    <option value="True">True</option>
                                    <option value="False">False</option>
                                </select>
                            </div>

                            <div id="fill_blanks_fields" style="display:none;">
                                <label class="form-label">Correct Answer</label>
                                <input type="text" name="fill_answer" class="form-control" required>
                            </div>

                            <label class="form-label">Marks</label>
                            <input type="number" name="marks" class="form-control" required>
                        </div>

                        <div class="modal-footer">
                            <button type="submit" name="add_question" class="btn btn-success">Add Question</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-header bg-primary text-white">
                <h5>Added Questions</h5>
            </div>
            <div class="card-body">
                <?php
        $sql = "SELECT * FROM questions WHERE exam_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $exam_id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            echo "<table class='table table-bordered'>";
            echo "<thead class='table-dark'>
                    <tr>
                        <th>#</th>
                        <th>Question</th>
                        <th>Type</th>
                        <th>Marks</th>
                        <th>Choices / Answer</th>
                    </tr>
                  </thead>";
            echo "<tbody>";
            $count = 1;
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $count++ . "</td>";
                echo "<td>" . htmlspecialchars($row['question_text']) . "</td>";
                echo "<td>" . htmlspecialchars($row['question_type']) . "</td>";
                echo "<td>" . htmlspecialchars($row['marks']) . "</td>";
                echo "<td>";
                
                if ($row['question_type'] === "Multiple Choice" || $row['question_type'] === "True/False") {
                    $sql_choices = "SELECT * FROM choices WHERE question_id = ?";
                    $stmt_choices = $conn->prepare($sql_choices);
                    $stmt_choices->bind_param("i", $row['question_id']);
                    $stmt_choices->execute();
                    $result_choices = $stmt_choices->get_result();
                    
                    $choice_labels = ['A', 'B', 'C', 'D'];
                    $index = 0;
                
                    while ($choice = $result_choices->fetch_assoc()) {
                        $correct = ($choice['is_correct'] == 1) ? "<span class='badge bg-success'>Correct</span>" : "";
                        echo "<p><strong>Choice " . $choice_labels[$index] . ":</strong> " . htmlspecialchars($choice['choice_text']) . " $correct</p>";
                        $index++;
                    }
                } elseif ($row['question_type'] === "Fill in the Blanks") {
                    $sql_answer = "SELECT choice_text FROM choices WHERE question_id = ?";
                    $stmt_answer = $conn->prepare($sql_answer);
                    $stmt_answer->bind_param("i", $row['question_id']);
                    $stmt_answer->execute();
                    $stmt_answer->bind_result($correct_answer);
                    $stmt_answer->fetch();
                    echo "<strong>Answer:</strong> " . htmlspecialchars($correct_answer);
                    $stmt_answer->close();
                }
                
                echo "</td>";
                
                echo "</tr>";
            }
            echo "</tbody>";
            echo "</table>";
        } else {
            echo "<p>No questions added yet.</p>";
        }
        ?>
            </div>
        </div>
        </main>
        </div>
        </div>
    </div>
    </div>

    <script src="assets/bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>