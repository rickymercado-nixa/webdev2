from tkinter import *
from tkinter import ttk
from PIL import Image, ImageTk
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import matplotlib.pyplot as plt
import mysql.connector
from tkinter import messagebox

def conn():
    try:
        db = mysql.connector.connect(host = "localhost", user = "root", password = "", database = "farm_animal")
        messagebox.showinfo("Database Connection", "Database Connected!")
        return db
    except mysql.connector.Error as e:
        messagebox.showerror("Database Connection", f"Failed to Connect Database: {e}")
        return None
    
deybe = conn()
if deybe is None:
    exit()

def register_form():
    for widget in window.winfo_children():
        widget.destroy()
    
    title = Label(window,text = 'Feeding Animal Guide App',font = ('Arial', 20),bg="#D9D9D9")
    title.pack()

    title = Label(window,text = 'Register Account',font = ('Arial', 14, 'bold'),bg="#D9D9D9")
    title.place(x=650,y=100)

    title = Label(window,text = 'Username:',font = ('Arial', 14, 'bold'),bg="#D9D9D9")
    title.place(x=650,y=150)

    title = Label(window,text = 'Password:',font = ('Arial', 14, 'bold'),bg="#D9D9D9")
    title.place(x=650,y=225)

    title = Label(window,text = 'Email:',font = ('Arial', 14, 'bold'),bg="#D9D9D9")
    title.place(x=650,y=300)

    title = Label(window,text = 'Already have an account?',font = ('Arial', 12, 'bold'),bg="#D9D9D9")
    title.place(x=650,y=425)

    label = Label(window,image = photo,bg="#D9D9D9")
    label.place(x=100,y=100)

    username_entry = Entry(window,font = ('Arial', 14, 'bold'))
    username_entry.place(x=650,y=175)

    password_entry = Entry(window,font = ('Arial', 14, 'bold'))
    password_entry.config(show='*')
    password_entry.place(x=650,y=250)

    email_entry = Entry(window,font = ('Arial', 14, 'bold'),)
    email_entry.place(x=650,y=325)
    
    def registers():
        deybe = conn()
        if deybe is None:
            return
        
        cursor = db.cursor()
        
        username = username_entry.get()
        password = password_entry.get()
        email = email_entry.get()
    
        if not all([username, password, email]):
            messagebox.showerror("Error", "All fields are required!")
            return
        try:
            conn = db()
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM users WHERE username = %s", (username))
            if cursor.fetchone():
                messagebox.showerror("Error", "Username already exist!")
                cursor.close()
                conn.close()
                return
            cursor.execute("INSERT INTO users (username, password, email) VALUES (%s, %s, %s)", (username, password, email))
            conn.commit()
            cursor.close()
            conn.close()
            messagebox.info("SUCCESS", "Register Successfully")
            window.destroy()
        except mysql.connector.Error as e:
            messagebox.showerror("DB Error:", str(e))
            return
        finally:
            cursor.close()
            deybe.close()
        
    button = Button(window,font = ('Arial', 14),bg = '#14AE5C',text = 'Create Account',command = registers)
    button.place(x=650,y=375)

    button = Button(window,font = ('Arial', 14),bg = '#14AE5C',text = 'Login',command = logins)
    button.place(x=855,y=420)
    '''
    title = Label(window,text = 'Register Successfully!!',font = ('Arial', 20))
    title.place(x=430,y=200)
    
    button = Button(window,text = 'Login',font = ('Arial', 14),command = logins)
    button.place(x=500,y=250)
    '''


def logins():
    for widget in window.winfo_children():
        widget.destroy()
        
    title = Label(window,text = 'Feeding Animal Guide App',font = ('Arial', 20),bg="#D9D9D9")
    title.pack()

    title = Label(window,text = 'Login Account',font = ('Arial', 14, 'bold'),bg="#D9D9D9")
    title.place(x=650,y=100)

    title = Label(window,text = 'Username:',font = ('Arial', 14, 'bold'),bg="#D9D9D9")
    title.place(x=650,y=150)

    title = Label(window,text = 'Password:',font = ('Arial', 14, 'bold'), bg="#D9D9D9")
    title.place(x=650,y=225)

    title = Label(window,text = "Don't have account?",font = ('Arial', 12, 'bold'),bg="#D9D9D9")
    title.place(x=650,y=360)

    label = Label(window,image = photo,bg="#D9D9D9")
    label.place(x=100,y=100)

    entry = Entry(window,font = ('Arial', 14, 'bold'))
    entry.place(x=650,y=175)

    entry = Entry(window,font = ('Arial', 14, 'bold'))
    entry.config(show='*')
    entry.place(x=650,y=250)

    button = Button(window,font = ('Arial', 14),bg = '#14AE5C',text = 'Login',command = dashboard)
    button.place(x=650,y=300)

    button = Button(window,font = ('Arial', 14),bg = '#14AE5C',text = 'Register',command = register_form)
    button.place(x=820,y=350)
    
def cost_analysis(main):
    animals = ['Dinosaur', 'Pig', 'Chicken', 'Cow']
    cost = [600, 500, 700, 900]
    
    fig, graph=plt.subplots(figsize=(5,4))
    graph.bar(animals, cost, color = 'red')
    graph.set_title('Monthly Cost Analysis')
    graph.set_xlabel('Animals')
    graph.set_ylabel('Cost')
    
    canvas = FigureCanvasTkAgg(fig, master=main)
    canvas.draw()
    bar_graph = canvas.get_tk_widget()
    bar_graph.place(x=150,y=50)
    
    
def dashboard():
    for widget in window.winfo_children():
        widget.destroy()
        
    button = Button(window, image=bell_icon, command=notification)
    button.place(x=970, y=10)
        
    sidebar = Frame(window, bg='#7A6961', width = 200, height = 600)
    sidebar.pack(side=LEFT,fill=Y)
    
    button = Button(sidebar, text='Cost Analysis', fg='black', bg='#D9D9D9', font=('Arial', 14), relief=FLAT, command=dashboard)
    button.pack(fill=X, pady=10, padx=10)
    
    button = Button(sidebar, text='Manage \nAnimal Profile', fg='black', bg='#D9D9D9', font=('Arial', 14), relief=FLAT, command=add_animals)
    button.pack(fill=X, pady=10, padx=10)
    
    button = Button(sidebar, text='Inventory', fg='black', bg='#D9D9D9', font=('Arial', 14), relief=FLAT, command=add_inventory)
    button.pack(fill=X, pady=10, padx=10)
    
    button = Button(sidebar, text='Feeding Log', fg='black', bg='#D9D9D9', font=('Arial', 14), relief=FLAT, command=feeding_log)
    button.pack(fill=X, pady=10, padx=10)
    
    button = Button(sidebar, text='Schedule \nFeeding', fg='black', bg='#D9D9D9', font=('Arial', 14), relief=FLAT, command=scheduling)
    button.pack(fill=X, pady=10, padx=10)
    
    button = Button(sidebar, text='Logout', fg='black', bg='#D9D9D9', font=('Arial', 14), relief=FLAT, command=logins)
    button.pack(fill=X, pady=10, padx=10)
    
    main = Frame(window, width = 700, height = 600, bg='#D9D9D9')
    label = Label(window, text='Farm Animal Feeding Guide', font=('Arial', 20), bg='#D9D9D9')
    label.pack()
    
    button = Button(window, text='Generate Reports', font=('Arial', 14))
    button.place(x=200,y=50)
    
    main.pack()
    
    cost_analysis(main)

def add_animals():
    for widget in window.winfo_children():
        widget.destroy()
        
    button = Button(window, image=bell_icon, command=notification)
    button.place(x=970, y=10)
        
    sidebar = Frame(window, bg='#7A6961', width = 200, height = 600)
    sidebar.pack(side=LEFT,fill=Y)
    
    button = Button(sidebar, text='Cost Analysis', fg='black', bg='#D9D9D9', font=('Arial', 14), relief=FLAT, command=dashboard)
    button.pack(fill=X, pady=10, padx=10)
    
    button = Button(sidebar, text='Manage \nAnimal Profile', fg='black', bg='#D9D9D9', font=('Arial', 14), relief=FLAT, command=add_animals)
    button.pack(fill=X, pady=10, padx=10)
    
    button = Button(sidebar, text='Inventory', fg='black', bg='#D9D9D9', font=('Arial', 14), relief=FLAT, command=add_inventory)
    button.pack(fill=X, pady=10, padx=10)
    
    button = Button(sidebar, text='Feeding Log', fg='black', bg='#D9D9D9', font=('Arial', 14), relief=FLAT, command=feeding_log)
    button.pack(fill=X, pady=10, padx=10)
    
    button = Button(sidebar, text='Schedule \nFeeding', fg='black', bg='#D9D9D9', font=('Arial', 14), relief=FLAT, command=scheduling)
    button.pack(fill=X, pady=10, padx=10)
    
    button = Button(sidebar, text='Logout', fg='black', bg='#D9D9D9', font=('Arial', 14), relief=FLAT, command=logins)
    button.pack(fill=X, pady=10, padx=10)
    
    main = Frame(window, width=700, height=600, bg='#D9D9D9')
    label = Label(window, text='Farm Animal Feeding Guide', font=('Arial', 20), bg='#D9D9D9')
    label.pack()
    
    label = Label(window, text='Add Animal:', font=('Arial', 14), bg='#D9D9D9')
    label.place(x=200,y=120)
    entry = Entry(window, font=('Arial', 14))
    entry.place(x=200,y=150)
    
    label = Label(window, text='Add Feeding Instruction:', font=('Arial', 14), bg='#D9D9D9')
    label.place(x=200,y=190)
    textarea = Text(window, font=('Arial', 14), width=20, height=8)
    textarea.place(x=200,y=220)
    
    label = Label(window, text='Search Animal:', font=('Arial', 14), bg='#D9D9D9')
    label.place(x=500,y=150)
    search_bar = Entry(window, font=('Arial', 14))
    search_bar.place(x=630,y=150)
    
    animals = [
        ("Cow", "Mga sagbot pakaonon"),
        ("Chicken", "Mais pakaonon"),
        ("Pig", "Pig feeds og sagbot"),
    ]
    
    headings = ("Animals", "Feeding Instructions", "Actions")
    
    table = ttk.Treeview(window, columns=headings, show="headings", height=5)
    
    for col in headings:
        table.heading(col, text=col)
        table.column(col, anchor='center', width=150)
    
    for row in animals:
        table.insert("", END, values=row + ('Update | Delete',))
        
    table.place(x=500, y=190)
    
    button = Button(window, text='Add Animal', font=('Arial', 14), bg='#14AE5C')
    button.place(x=200,y=420)
    main.pack()
    
def add_inventory():
    for widget in window.winfo_children():
        widget.destroy()
        
    button = Button(window, image=bell_icon, command=notification)
    button.place(x=970, y=10)
        
    sidebar = Frame(window, bg='#7A6961', width = 200, height = 600)
    sidebar.pack(side=LEFT,fill=Y)
    
    button = Button(sidebar, text='Cost Analysis', fg='black', bg='#D9D9D9', font=('Arial', 14), relief=FLAT, command=dashboard)
    button.pack(fill=X, pady=10, padx=10)
    
    button = Button(sidebar, text='Manage \nAnimal Profile', fg='black', bg='#D9D9D9', font=('Arial', 14), relief=FLAT, command=add_animals)
    button.pack(fill=X, pady=10, padx=10)
    
    button = Button(sidebar, text='Inventory', fg='black', bg='#D9D9D9', font=('Arial', 14), relief=FLAT, command=add_inventory)
    button.pack(fill=X, pady=10, padx=10)
    
    button = Button(sidebar, text='Feeding Log', fg='black', bg='#D9D9D9', font=('Arial', 14), relief=FLAT, command=feeding_log)
    button.pack(fill=X, pady=10, padx=10)
    
    button = Button(sidebar, text='Schedule \nFeeding', fg='black', bg='#D9D9D9', font=('Arial', 14), relief=FLAT, command=scheduling)
    button.pack(fill=X, pady=10, padx=10)
    
    button = Button(sidebar, text='Logout', fg='black', bg='#D9D9D9', font=('Arial', 14), relief=FLAT, command=logins)
    button.pack(fill=X, pady=10, padx=10)
    
    main = Frame(window, width=700, height=600, bg='#D9D9D9')
    label = Label(window, text='Add Inventory', font=('Arial', 20), bg='#D9D9D9')
    label.pack()
    
    label = Label(window, text='Add Feeds:', font=('Arial', 14), bg='#D9D9D9')
    label.place(x=200,y=50)
    entry = Entry(window, font=('Arial', 14))
    entry.place(x=200,y=80)
        
    label = Label(window, text='Cost ₱:', font=('Arial', 14), bg='#D9D9D9')
    label.place(x=450,y=50)
    entry = Entry(window, font=('Arial', 14))
    entry.place(x=450,y=80)
    
    label = Label(window, text='Feeds KG/LBS:', font=('Arial', 14), bg='#D9D9D9')
    label.place(x=700,y=50)
    entry = Entry(window, font=('Arial', 14))
    entry.place(x=700,y=80)
    
    Filter = ["Cost Ascending", "Cost Descending", "A-Z"]
    
    label = Label(window, text='Filter Inventory:', font=('Arial', 14), bg='#D9D9D9')
    label.place(x=200,y=240)
    filter_inventory = ttk.Combobox(window, values=Filter, font=('Arial', 14))
    filter_inventory.set("Filter:")
    filter_inventory.place(x=200,y=270)
    
    inventory = [
        ("Cow", "Integra1", "4", "100"),
        ("Chicken", "Integra2", "5", "200"),
        ("Pig", "Integra 3",  "8", "500"),
    ]
    
    headings = ("Animals", "Feeds", "KILO/LBS", "Cost", "Actions")
    
    table = ttk.Treeview(window, columns=headings, show="headings", height=5)
    
    for col in headings:
        table.heading(col, text=col, anchor='center')
        table.column(col, anchor='center', width=150)
    
    for row in inventory:
        table.insert("", END, values=row + ('Update | Delete',))
        
    table.place(x=200,y=300)
    
    button = Button(window, text='Add Inventory', font=('Arial', 14), bg='#14AE5C')
    button.place(x=200,y=120)
    
    main.pack()

def feeding_log():
    for widget in window.winfo_children():
        widget.destroy()
        
    button = Button(window, image=bell_icon, command=notification)
    button.place(x=970, y=10)
        
    sidebar = Frame(window, bg='#7A6961', width = 200, height = 600)
    sidebar.pack(side=LEFT,fill=Y)
    
    button = Button(sidebar, text='Cost Analysis', fg='black', bg='#D9D9D9', font=('Arial', 14), relief=FLAT, command=dashboard)
    button.pack(fill=X, pady=10, padx=10)
    
    button = Button(sidebar, text='Manage \nAnimal Profile', fg='black', bg='#D9D9D9', font=('Arial', 14), relief=FLAT, command=add_animals)
    button.pack(fill=X, pady=10, padx=10)
    
    button = Button(sidebar, text='Inventory', fg='black', bg='#D9D9D9', font=('Arial', 14), relief=FLAT, command=add_inventory)
    button.pack(fill=X, pady=10, padx=10)
    
    button = Button(sidebar, text='Feeding Log', fg='black', bg='#D9D9D9', font=('Arial', 14), relief=FLAT, command=feeding_log)
    button.pack(fill=X, pady=10, padx=10)
    
    button = Button(sidebar, text='Schedule \nFeeding', fg='black', bg='#D9D9D9', font=('Arial', 14), relief=FLAT, command=scheduling)
    button.pack(fill=X, pady=10, padx=10)
    
    button = Button(sidebar, text='Logout', fg='black', bg='#D9D9D9', font=('Arial', 14), relief=FLAT, command=logins)
    button.pack(fill=X, pady=10, padx=10)
    
    main = Frame(window, width=700, height=600, bg='#D9D9D9')
    label = Label(window, text='Feeding Log', font=('Arial', 20), bg='#D9D9D9')
    label.pack()
    
    animals = ["Chicken", "Pig", "Cow"]
    
    label = Label(window, text='Select Animals:', font=('Arial', 14), bg='#D9D9D9')
    label.place(x=200,y=50)
    select_animals = ttk.Combobox(window, values=animals, font=('Arial', 14))
    select_animals.set("Select Animals:")
    select_animals.place(x=200,y=80)
    
    label = Label(window, text='Feeds Type:', font=('Arial', 14), bg='#D9D9D9')
    label.place(x=500,y=50)
    entry = Entry(window, font=('Arial', 14))
    entry.place(x=500,y=80)
    
    label = Label(window, text='Feeds KG/LBS:', font=('Arial', 14), bg='#D9D9D9')
    label.place(x=200,y=120)
    entry = Entry(window, font=('Arial', 14))
    entry.place(x=200,y=150)
    
    label = Label(window, text='Feed Cost:', font=('Arial', 14), bg='#D9D9D9')
    label.place(x=500,y=120)
    entry = Entry(window, font=('Arial', 14))
    entry.place(x=500,y=150)
    
    Filter = ("A-Z", "Feed Cost", "Ascending", "Descending")
    
    label = Label(window, text="Filter Feed Logs: ", font=("Arial", 14), bg='#D9D9D9')
    label.place(x=200,y=300)
    
    Filter_logs = ttk.Combobox(window, values=Filter, font=("Arial", 14))
    Filter_logs.set("Filter Logs:")
    Filter_logs.place(x=200,y=300)
    
    feed_logs = [
        ("Cow", "Integra1", "2", "50"),
        ("Chicken", "Integra2", "3", "100"),
        ("Pig", "Integra 3",  "2", "300"),
    ]
    
    headings = ("Animals", "Feeds Type", "KILO/LBS", "Feed Cost", "Actions")
    
    table = ttk.Treeview(window, columns=headings, show="headings", height=5)
    
    for col in headings:
        table.heading(col, text=col)
        table.column(col, anchor='center', width=100)
    
    for row in feed_logs:
        table.insert("", END, values=row + ('Update | Delete',))
        
    table.place(x=500,y=300)
    
    button = Button(window, text='Add Feed Log',font=('Arial', 14), bg='#14AE5C')
    button.place(x=200, y=200)
    
    main.pack()

def scheduling():
    for widget in window.winfo_children():
        widget.destroy()
        
    button = Button(window, image=bell_icon, command=notification)
    button.place(x=970, y=10)
        
    sidebar = Frame(window, bg='#7A6961', width = 200, height = 600)
    sidebar.pack(side=LEFT,fill=Y)
    
    button = Button(sidebar, text='Cost Analysis', fg='black', bg='#D9D9D9', font=('Arial', 14), relief=FLAT, command=dashboard)
    button.pack(fill=X, pady=10, padx=10)
    
    button = Button(sidebar, text='Manage \nAnimal Profile', fg='black', bg='#D9D9D9', font=('Arial', 14), relief=FLAT, command=add_animals)
    button.pack(fill=X, pady=10, padx=10)
    
    button = Button(sidebar, text='Inventory', fg='black', bg='#D9D9D9', font=('Arial', 14), relief=FLAT, command=add_inventory)
    button.pack(fill=X, pady=10, padx=10)
    
    button = Button(sidebar, text='Feeding Log', fg='black', bg='#D9D9D9', font=('Arial', 14), relief=FLAT, command=feeding_log)
    button.pack(fill=X, pady=10, padx=10)
    
    button = Button(sidebar, text='Schedule \nFeeding', fg='black', bg='#D9D9D9', font=('Arial', 14), relief=FLAT, command=scheduling)
    button.pack(fill=X, pady=10, padx=10)
    
    button = Button(sidebar, text='Logout', fg='black', bg='#D9D9D9', font=('Arial', 14), relief=FLAT, command=logins)
    button.pack(fill=X, pady=10, padx=10)
    
    main = Frame(window, width=700, height=600, bg='#D9D9D9')
    label = Label(window, text='Scheduling', font=('Arial', 20), bg='#D9D9D9')
    label.pack()
    
    label = Label(window, text="Select Animals: ", font=("Arial", 14), bg='#D9D9D9')
    label.place(x=200,y=150)
    
    animals = ("Chicken", "Cow", "Pig")
    
    select_animals = ttk.Combobox(window, values=animals, font=("Arial", 14))
    select_animals.set("Select Animals: ")
    select_animals.place(x=200,y=180)
    
    label = Label(window, text="Time:", font=("Arial", 14), bg='#D9D9D9')
    label.place(x=200,y=220)
    
    entry = Entry(window, font=("Arial", 14))
    entry.place(x=200,y=250)
    
    button = Button(window, text="Submit", font=("Arial", 14), bg='#14AE5C')
    button.place(x=200,y=300)

    schedule = [
        ("Chicken", "11:30 AM"),
        ("Cow", "1:00 PM"),
        ("Pig", "3:00 PM"),
        ]
    
    headings =("Animals", "Time", "Actions")
    
    table = ttk.Treeview(window, columns=headings, show="headings")
    
    for col in headings:
        table.heading(col, text=col)
        table.column(col, anchor='center', width=100)
        
    for row in schedule:
        table.insert("", END, values=row + ('Update | Delete',))
        
    table.place(x=600,y=150)
    
    main.pack()
    
def notification():
    for widget in window.winfo_children():
        widget.destroy()
    
    sidebar = Frame(window, bg='#7A6961', width = 200, height = 600)
    sidebar.pack(side=LEFT,fill=Y)
    
    button = Button(sidebar, text='Cost Analysis', fg='black', bg='#D9D9D9', font=('Arial', 14), relief=FLAT, command=dashboard)
    button.pack(fill=X, pady=10, padx=10)
    
    button = Button(sidebar, text='Manage \nAnimal Profile', fg='black', bg='#D9D9D9', font=('Arial', 14), relief=FLAT, command=add_animals)
    button.pack(fill=X, pady=10, padx=10)
    
    button = Button(sidebar, text='Inventory', fg='black', bg='#D9D9D9', font=('Arial', 14), relief=FLAT, command=add_inventory)
    button.pack(fill=X, pady=10, padx=10)
    
    button = Button(sidebar, text='Feeding Log', fg='black', bg='#D9D9D9', font=('Arial', 14), relief=FLAT, command=feeding_log)
    button.pack(fill=X, pady=10, padx=10)
    
    button = Button(sidebar, text='Schedule \nFeeding', fg='black', bg='#D9D9D9', font=('Arial', 14), relief=FLAT, command=scheduling)
    button.pack(fill=X, pady=10, padx=10)
    
    button = Button(sidebar, text='Logout', fg='black', bg='#D9D9D9', font=('Arial', 14), relief=FLAT, command=logins)
    button.pack(fill=X, pady=10, padx=10)
    
    main = Frame(window, width=820, height=600, bg='#D9D9D9')
    label = Label(window, text="Notification", font=("Arial", 14), bg='#D9D9D9')
    label.pack()
    
    notif = [
        ("Chicken at 11:30 AM",),
        ("Cow at 1:00 PM",),
        ("Pig at 3:00 PM",),
        ("Integra5 is below 10%",),
        ("BMEG700 is below 10%",),
        ]
    
    table = ttk.Treeview(window, columns="Notification", show="headings")
    
    table.heading("Notification", text="Notification")
    table.column("Notification", anchor="center", width=300)
        
    for row in notif:
        table.insert("", END, values=row)
        
    table.pack(pady=150)

    main.pack()

window = Tk()
window.geometry("1020x520")
window.title("Mercado GUI")

window.iconbitmap("user.ico")
#icon = PhotoImage(file="c.png")
#window.iconphoto(True,icon)
window.config(background="#D9D9D9")

image_path = 'c.png'
image = Image.open(image_path)
image = image.resize((400,300))
photo = ImageTk.PhotoImage(image)

bell_path = 'bell (1).png'
bell = Image.open(bell_path)
bell = bell.resize((30,30))
bell_icon = ImageTk.PhotoImage(bell)

logins()

window.mainloop()